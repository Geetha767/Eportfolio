import { Section } from "./Section";
import { GraduationCap, Code2, Users, Heart } from "lucide-react";

const points = [
  { icon: GraduationCap, label: "B.Tech CSE", value: "Manav Rachna University" },
  { icon: Code2, label: "Focus", value: "Software, Data & DSA" },
  { icon: Users, label: "Roles", value: "R&D Intern · Ambassador" },
  { icon: Heart, label: "Impact", value: "Volunteer Educator" },
];

export function About() {
  return (
    <Section id="about" eyebrow="About" title="A student building with intent.">
      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-12 items-start">
        <div className="space-y-5 text-lg leading-relaxed text-muted-foreground reveal">
          <p>
            I am pursuing my{" "}
            <span className="text-foreground font-medium">
              B.Tech in Computer Science at Manav Rachna University
            </span>
            , currently holding a CGPA of{" "}
            <span className="text-foreground font-medium">9.28/10</span>. My academic
            journey has been recognized through the Vice-Chancellor’s List and the
            Dean’s List on three occasions.
          </p>
          <p>
            I’m passionate about technology, problem-solving, data handling, and
            building practical digital solutions that genuinely help people. I
            enjoy combining technical learning with communication, teamwork, and
            meaningful contribution.
          </p>
          <p>
            Beyond academics, I’m actively involved in student-centered work and
            social impact initiatives — from coordinating university research
            operations to teaching underprivileged children at a local NGO.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 reveal">
          {points.map((p) => (
            <div
              key={p.label}
              className="rounded-2xl border border-border bg-card p-5 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-smooth"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-primary text-primary-foreground flex items-center justify-center mb-4 shadow-glow">
                <p.icon className="h-5 w-5" />
              </div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">
                {p.label}
              </div>
              <div className="font-medium">{p.value}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}