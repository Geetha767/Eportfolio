import { Section } from "./Section";
import { Music, Sparkles, Award } from "lucide-react";

const highlights = [
  {
    icon: Music,
    title: "Classical Indian Dance",
    description:
      "Trained Kuchipudi dancer with years of disciplined practice in one of India's classical dance traditions.",
  },
  {
    icon: Sparkles,
    title: "Stage Performances",
    description:
      "Performed at university cultural events and felicitation ceremonies, representing heritage through art.",
  },
  {
    icon: Award,
    title: "Discipline & Expression",
    description:
      "Cultivates focus, creative expression, and stage confidence — qualities I bring into academics and teamwork.",
  },
];

export function Extracurricular() {
  return (
    <Section
      id="extracurricular"
      eyebrow="Beyond Academics"
      title="Extracurricular Activities."
      description="Outside the classroom, I dedicate time to classical art, cultural expression, and personal growth — pursuits that shape my discipline and creativity."
    >
      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-10 items-start">
        <div className="rounded-3xl border border-border bg-card p-8 md:p-10 shadow-card reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-5">
            <Music className="h-3.5 w-3.5" />
            Kuchipudi Dancer
          </div>
          <h3 className="font-display text-2xl md:text-3xl font-semibold mb-4 leading-tight">
            A passionate Kuchipudi dancer, carrying forward a classical Indian
            tradition with grace and dedication.
          </h3>
          <p className="text-muted-foreground leading-relaxed mb-4">
            Kuchipudi — a centuries-old classical dance form from Andhra
            Pradesh — has been an integral part of my journey. Years of rigorous
            training have shaped my sense of discipline, rhythm, expression, and
            stage presence.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            I have had the privilege of performing at university events and
            cultural ceremonies, blending storytelling, music, and movement.
            This artistic pursuit balances my technical learning with creativity
            and cultural rootedness.
          </p>
        </div>

        <div className="grid sm:grid-cols-1 gap-4">
          {highlights.map((h, i) => (
            <div
              key={h.title}
              className="reveal flex gap-4 items-start rounded-2xl border border-border bg-card p-5 shadow-card hover:shadow-elegant hover:-translate-y-0.5 transition-smooth"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="w-11 h-11 shrink-0 rounded-xl bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow">
                <h.icon className="h-5 w-5" />
              </div>
              <div>
                <h4 className="font-display font-semibold mb-1">{h.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {h.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}