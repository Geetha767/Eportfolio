import { Section } from "./Section";
import { Code, Globe, Wrench, Users } from "lucide-react";

const groups = [
  {
    icon: Code,
    title: "Programming, DSA & Databases",
    skills: ["Python", "C", "Java", "JavaScript", "MySQL", "Data Structures & Algorithms"],
  },
  {
    icon: Globe,
    title: "Web & Development",
    skills: ["HTML", "CSS", "Web Designing", "Firebase"],
  },
  {
    icon: Wrench,
    title: "Tools & Platforms",
    skills: ["VS Code", "Jupyter Notebook", "Google Colab", "Git", "GitHub", "Altair", "Udemy"],
  },
  {
    icon: Users,
    title: "Soft Skills",
    skills: [
      "Team Leadership",
      "Analytical Problem Solving",
      "Strategic Planning",
      "Communication",
      "Cross-functional Collaboration",
      "Event Coordination",
    ],
  },
];

export function Skills() {
  return (
    <Section
      id="skills"
      eyebrow="Skills"
      title="Toolkit & strengths."
      description="A balance of technical depth and people-centered abilities."
    >
      <div className="grid md:grid-cols-2 gap-6">
        {groups.map((g, i) => (
          <div
            key={g.title}
            className="rounded-2xl border border-border bg-card p-7 shadow-card hover:shadow-elegant transition-smooth reveal"
            style={{ transitionDelay: `${i * 80}ms` }}
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow">
                <g.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg font-semibold">{g.title}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {g.skills.map((s) => (
                <span
                  key={s}
                  className="px-3 py-1.5 text-sm rounded-full bg-secondary text-secondary-foreground border border-border hover:border-primary hover:text-primary transition-smooth cursor-default"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}