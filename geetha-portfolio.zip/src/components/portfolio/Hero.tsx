import { ArrowRight, Mail, Download, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import portrait from "@/assets/geetha-portrait.jpeg";

export function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden bg-gradient-subtle"
    >
      <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />
      <div
        className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full opacity-30 blur-3xl animate-float"
        style={{ background: "var(--gradient-primary)" }}
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10 grid lg:grid-cols-[1.3fr_1fr] gap-16 items-center">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-border bg-card/60 backdrop-blur text-xs text-muted-foreground mb-6">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Open to internships & collaborations
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-semibold leading-[1.05] mb-6">
            Nalluri <br />
            <span className="text-gradient">Geetha Manaswini</span>
          </h1>

          <p className="text-base md:text-lg text-muted-foreground font-medium mb-5">
            Computer Science Undergraduate{" "}
            <span className="text-foreground/60">·</span> Research & Development
            Intern <span className="text-foreground/60">·</span> Student Leader
          </p>

          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mb-4 leading-relaxed">
            B.Tech CSE student at Manav Rachna University with a CGPA of{" "}
            <span className="text-foreground font-semibold">9.28/10</span>.
            Recognized on the Vice-Chancellor’s List, Dean’s List (3×), and
            actively contributing to research, technology projects, and student
            initiatives.
          </p>

          <p className="text-sm md:text-base text-foreground/80 italic max-w-2xl mb-10">
            “Building practical solutions, supporting communities, and growing
            through technology, leadership, and continuous learning.”
          </p>

          <div className="flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-gradient-primary text-primary-foreground shadow-elegant hover:shadow-glow transition-smooth border-0">
              <a href="#projects">
                View Projects <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-primary/30 hover:bg-primary/5 transition-smooth">
              <a href="#contact">
                <Mail className="mr-2 h-4 w-4" /> Contact Me
              </a>
            </Button>
            <Button asChild size="lg" variant="ghost" className="text-muted-foreground hover:text-foreground">
              <a
                href="/Geetha_Manaswini_Resume.pdf"
                download
                target="_blank"
                rel="noopener noreferrer"
              >
                <Download className="mr-2 h-4 w-4" /> Resume
              </a>
            </Button>
          </div>
        </div>

        <div className="relative hidden lg:flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-primary opacity-20 blur-3xl rounded-full" />
          <div className="relative w-80 h-80 rounded-full bg-gradient-primary p-1.5 shadow-elegant animate-float">
            <img
              src={portrait}
              alt="Nalluri Geetha Manaswini portrait"
              className="w-full h-full rounded-full object-cover bg-card"
              loading="eager"
            />
          </div>
          <div className="absolute -bottom-4 -left-4 px-4 py-3 rounded-2xl bg-card border border-border shadow-card">
            <div className="text-xs text-muted-foreground">CGPA</div>
            <div className="font-display font-semibold text-2xl text-gradient">9.28</div>
          </div>
          <div className="absolute -top-4 -right-4 px-4 py-3 rounded-2xl bg-card border border-border shadow-card">
            <div className="text-xs text-muted-foreground">Honors</div>
            <div className="font-display font-semibold text-sm">VC + Dean's List</div>
          </div>
        </div>
      </div>
    </section>
  );
}