import { Section } from "./Section";
import { Award, BookOpen } from "lucide-react";

const education = [
  {
    school: "Manav Rachna University",
    degree: "Bachelor of Technology — Computer Science",
    period: "July 2024 – May 2028",
    location: "Faridabad, Haryana",
    score: "CGPA 9.28 / 10",
    honors: "Vice-Chancellor’s List · Dean’s List (3×)",
  },
  {
    school: "Bhashyam Junior College",
    degree: "Class XII — Andhra Pradesh State Board",
    period: "June 2022 – May 2024",
    location: "Guntur, Andhra Pradesh",
    score: "97.8%",
  },
  {
    school: "Bhashyam Blooms",
    degree: "Class X — CBSE",
    period: "June 2021 – May 2022",
    location: "Guntur, Andhra Pradesh",
    score: "96.6%",
  },
];

const coursework = [
  "Data Structures & Algorithms",
  "C",
  "Python Programming",
  "Java",
  "Web Designing",
  "SQL & Database Systems",
];

export function Education() {
  return (
    <Section
      id="education"
      eyebrow="Education"
      title="Academic foundation."
      description="Consistent academic performance backed by strong fundamentals across school and university."
      className="bg-gradient-subtle"
    >
      <div className="grid lg:grid-cols-[2fr_1fr] gap-10">
        <div className="relative">
          <div className="absolute left-4 top-2 bottom-2 w-px bg-gradient-to-b from-primary via-primary/40 to-transparent" />
          <div className="space-y-6">
            {education.map((e, i) => (
              <div
                key={e.school}
                className="relative pl-14 reveal"
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="absolute left-1.5 top-3 w-5 h-5 rounded-full bg-gradient-primary shadow-glow ring-4 ring-background" />
                <div className="rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant transition-smooth">
                  <div className="flex flex-wrap justify-between items-start gap-3 mb-2">
                    <div>
                      <h3 className="font-display text-xl font-semibold">
                        {e.school}
                      </h3>
                      <p className="text-sm text-muted-foreground">{e.degree}</p>
                    </div>
                    <span className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                      {e.period}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mt-3">
                    <span>{e.location}</span>
                    <span className="font-medium text-foreground">{e.score}</span>
                    {e.honors && (
                      <span className="inline-flex items-center gap-1.5 text-primary">
                        <Award className="h-3.5 w-3.5" />
                        {e.honors}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-card reveal h-fit lg:sticky lg:top-24">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="h-5 w-5 text-primary" />
            <h3 className="font-display text-lg font-semibold">
              Relevant Coursework
            </h3>
          </div>
          <ul className="space-y-2.5">
            {coursework.map((c) => (
              <li
                key={c}
                className="flex items-center gap-3 text-sm text-muted-foreground"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-gradient-primary" />
                {c}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}