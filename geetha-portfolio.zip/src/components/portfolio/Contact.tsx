import { Section } from "./Section";
import { Mail, Phone, MapPin, Linkedin, Github, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const channels = [
  { icon: Mail, label: "Email", value: "manunalluri76@gmail.com", href: "mailto:manunalluri76@gmail.com" },
  { icon: Phone, label: "Phone", value: "+91 89776 31474", href: "tel:+918977631474" },
  { icon: MapPin, label: "Location", value: "Faridabad, Haryana, India", href: null },
  { icon: Linkedin, label: "LinkedIn", value: "geetha-manaswini-nalluri", href: "https://www.linkedin.com/in/geetha-manaswini-nalluri-35a4b3345/" },
  { icon: Github, label: "GitHub", value: "Geetha767", href: "https://github.com/Geetha767" },
];

export function Contact() {
  return (
    <Section
      id="contact"
      eyebrow="Contact"
      title="Let’s build something meaningful."
      description="I’m open to internships, collaborations, learning opportunities, and meaningful conversations around technology, innovation, and student development."
      className="bg-gradient-subtle"
    >
      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-8 items-start">
        <div className="rounded-3xl bg-gradient-primary p-10 text-primary-foreground shadow-elegant reveal">
          <h3 className="font-display text-3xl font-semibold mb-4">
            Reach out anytime.
          </h3>
          <p className="text-primary-foreground/85 leading-relaxed mb-8">
            Whether it’s an internship opportunity, a project idea, or a quick
            chat — I’d love to hear from you.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild size="lg" variant="secondary" className="shadow-card">
              <a href="mailto:manunalluri76@gmail.com">
                <Mail className="mr-2 h-4 w-4" /> Email Me
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent border-primary-foreground/40 text-primary-foreground hover:bg-primary-foreground/10"
            >
              <a
                href="https://www.linkedin.com/in/geetha-manaswini-nalluri-35a4b3345/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Linkedin className="mr-2 h-4 w-4" /> Connect on LinkedIn
              </a>
            </Button>
          </div>
        </div>

        <div className="space-y-3 reveal">
          {channels.map((c) => {
            const Wrap: any = c.href ? "a" : "div";
            const props = c.href
              ? { href: c.href, target: c.href.startsWith("http") ? "_blank" : undefined, rel: "noopener noreferrer" }
              : {};
            return (
              <Wrap
                key={c.label}
                {...props}
                className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-5 shadow-card hover:shadow-elegant hover:-translate-y-0.5 transition-smooth"
              >
                <div className="w-11 h-11 rounded-xl bg-secondary text-primary flex items-center justify-center group-hover:bg-gradient-primary group-hover:text-primary-foreground transition-smooth">
                  <c.icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">
                    {c.label}
                  </div>
                  <div className="font-medium truncate">{c.value}</div>
                </div>
                {c.href && (
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-smooth" />
                )}
              </Wrap>
            );
          })}
        </div>
      </div>
    </Section>
  );
}