import { cn } from "@/lib/utils";

export function Section({
  id,
  eyebrow,
  title,
  description,
  children,
  className,
}: {
  id: string;
  eyebrow?: string;
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={cn("py-24 md:py-32 scroll-mt-20", className)}>
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-3xl mb-14 reveal">
          {eyebrow && (
            <div className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-3">
              {eyebrow}
            </div>
          )}
          <h2 className="text-4xl md:text-5xl font-semibold mb-4">{title}</h2>
          {description && (
            <p className="text-lg text-muted-foreground leading-relaxed">
              {description}
            </p>
          )}
        </div>
        {children}
      </div>
    </section>
  );
}