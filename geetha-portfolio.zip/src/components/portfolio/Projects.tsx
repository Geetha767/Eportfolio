import { Section } from "./Section";
import { Sparkles, ArrowUpRight, Wrench, ClipboardList, Network } from "lucide-react";

const projects = [
  {
    featured: true,
    title: "Fixify",
    icon: Wrench,
    tagline: "Smart on-demand service platform",
    description:
      "A smart on-demand platform that connects users with skilled service providers — electricians, plumbers, cleaners — in a fast, transparent, and reliable way. Combines service booking, real-time tracking, and AI assistance to elevate convenience and service management.",
    impact: "User-focused, real-world digital solution that streamlines local services.",
    tags: ["AI Assistance", "Real-time Tracking", "Service Booking", "UX"],
  },
  {
    title: "Attendance Monitoring System",
    icon: ClipboardList,
    status: "In Progress",
    tagline: "Automated attendance & analytics",
    description:
      "A technology-driven system to automate and streamline attendance tracking — collecting, validating, and organizing data into structured digital records, with participation analysis and report generation.",
    impact: "Reduces manual errors and improves administrative efficiency.",
    tags: ["Automation", "Data Validation", "Reporting"],
  },
  {
    title: "Legacy Link",
    icon: Network,
    tagline: "Student – alumni engagement",
    description:
      "A student-led initiative strengthening student–alumni connections. Contributed through coordination, communication, documentation, report preparation, and support for mentorship and networking programs.",
    impact: "Bridged students and alumni through structured engagement programs.",
    tags: ["Coordination", "Mentorship", "Documentation"],
  },
];

export function Projects() {
  return (
    <Section
      id="projects"
      eyebrow="Projects"
      title="Things I've built and led."
      description="A mix of full-stack ideas, automation tools, and student-led initiatives."
      className="bg-gradient-subtle"
    >
      <div className="grid lg:grid-cols-3 gap-6">
        {projects.map((p, i) => (
          <article
            key={p.title}
            className={`group relative rounded-3xl border border-border bg-card p-7 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-smooth reveal ${
              p.featured ? "lg:col-span-2 lg:row-span-1" : ""
            }`}
            style={{ transitionDelay: `${i * 100}ms` }}
          >
            {p.featured && (
              <div className="absolute top-5 right-5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-primary text-primary-foreground text-xs font-semibold shadow-glow">
                <Sparkles className="h-3 w-3" /> Featured
              </div>
            )}
            {p.status && (
              <div className="absolute top-5 right-5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                {p.status}
              </div>
            )}

            <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center text-primary-foreground shadow-glow mb-5">
              <p.icon className="h-5 w-5" />
            </div>

            <h3 className="font-display text-2xl font-semibold mb-1.5 flex items-center gap-2">
              {p.title}
              <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-smooth" />
            </h3>
            <p className="text-sm text-primary font-medium mb-4">{p.tagline}</p>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              {p.description}
            </p>
            <p className="text-sm text-foreground/80 italic mb-5">
              {p.impact}
            </p>

            <div className="flex flex-wrap gap-2">
              {p.tags.map((t) => (
                <span
                  key={t}
                  className="text-xs px-2.5 py-1 rounded-full border border-border bg-secondary text-secondary-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}