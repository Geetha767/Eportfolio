import { Section } from "./Section";
import { Heart } from "lucide-react";

const contributions = [
  "Taught basic academic subjects to underprivileged students.",
  "Simplified concepts and helped improve student confidence.",
  "Assisted in mentoring and classroom activities.",
  "Contributed to community education and broader social impact.",
];

export function SocialImpact() {
  return (
    <Section id="impact" eyebrow="Social Impact" title="Giving back, with intent.">
      <div className="rounded-3xl border border-border bg-card overflow-hidden shadow-card reveal">
        <div className="grid md:grid-cols-[1fr_1.4fr]">
          <div className="bg-gradient-primary p-10 text-primary-foreground flex flex-col justify-between">
            <div>
              <Heart className="h-8 w-8 mb-6" />
              <h3 className="font-display text-3xl font-semibold mb-2">
                Volunteer Teacher
              </h3>
              <p className="text-primary-foreground/85">Sai Dham NGO</p>
            </div>
            <p className="text-sm text-primary-foreground/85 mt-8 italic">
              “Education is the most powerful tool to lift each other up.”
            </p>
          </div>
          <div className="p-10">
            <p className="text-muted-foreground leading-relaxed mb-6">
              I volunteer as a teacher with Sai Dham NGO, supporting children
              who deserve every opportunity to learn and thrive. The role keeps
              me grounded and reminds me why I build.
            </p>
            <ul className="space-y-3">
              {contributions.map((c) => (
                <li key={c} className="flex gap-3 text-sm text-foreground/85">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-gradient-primary shrink-0" />
                  {c}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Section>
  );
}