import { Section } from "./Section";
import { Trophy } from "lucide-react";
import vcListImg from "@/assets/geetha-vc-list.jpeg";
import deansListImg from "@/assets/geetha-deans-list.jpeg";

const achievements = [
  {
    title: "First Prize",
    event: "Altair Data Science Contest",
    description:
      "Top recognition in a competitive data science challenge among peers.",
  },
  {
    title: "First Prize",
    event: "Google Digital Campus Hackathon 2.0",
    description:
      "Won the campus-wide hackathon focused on digital innovation and problem-solving.",
  },
];

export function Achievements() {
  return (
    <Section
      id="achievements"
      eyebrow="Recognition"
      title="Achievements & Recognition."
      className="bg-gradient-subtle"
    >
      <div className="grid md:grid-cols-2 gap-6">
        {achievements.map((a, i) => (
          <div
            key={a.event}
            className="relative overflow-hidden rounded-2xl border border-border bg-card p-7 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-smooth reveal"
            style={{ transitionDelay: `${i * 100}ms` }}
          >
            <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-primary opacity-10 blur-2xl" />
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow mb-5">
                <Trophy className="h-6 w-6" />
              </div>
              <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-2">
                {a.title}
              </div>
              <h3 className="font-display text-2xl font-semibold mb-2">
                {a.event}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {a.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12">
        <div className="text-center mb-8 reveal">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-2">
            Academic Honors
          </div>
          <h3 className="font-display text-3xl font-semibold">
            Vice-Chancellor's List & Dean's List
          </h3>
          <p className="text-sm text-muted-foreground mt-2 max-w-2xl mx-auto">
            Recognized at Manav Rachna University for sustained academic excellence,
            being honored on the Vice-Chancellor's List and Dean's List (3×).
          </p>
        </div>
        <div className="grid sm:grid-cols-2 gap-6">
          {[
            { src: vcListImg, label: "Vice-Chancellor's List Felicitation" },
            { src: deansListImg, label: "Dean's List Certificates" },
          ].map((img, i) => (
            <div
              key={img.label}
              className="reveal group relative overflow-hidden rounded-2xl border border-border bg-card shadow-card hover:shadow-elegant transition-smooth"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src={img.src}
                  alt={img.label}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
                />
              </div>
              <div className="p-4 border-t border-border">
                <p className="text-sm font-medium">{img.label}</p>
                <p className="text-xs text-muted-foreground">Manav Rachna University</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}