import { Section } from "./Section";
import { Briefcase, Megaphone } from "lucide-react";

const experiences = [
  {
    icon: Briefcase,
    role: "Junior Intern — Research and Development",
    org: "MR Impact 4.0 · Manav Rachna University",
    period: "September 2025 – Present",
    bullets: [
      "Maintain and update student-centric records and databases for university R&D operations.",
      "Coordinate communication with students regarding clubs, societies, activities, and deadlines.",
      "Prepare student activity reports and IQAC documentation.",
      "Conduct faculty-wise and month-wise R&D data analysis to surface trends.",
      "Support ICAICCIT-2025 conference operations — registration data collection, filtering, segregation, analysis, and documentation coordination.",
    ],
  },
  {
    icon: Megaphone,
    role: "Campus Ambassador",
    org: "Unstop",
    period: "August 2025 – March 2026",
    bullets: [
      "Promoted career-enhancing events, hackathons, and learning opportunities across campus.",
      "Led outreach campaigns and online promotions to drive student participation.",
      "Encouraged peers to explore skill-building platforms and competitions.",
      "Strengthened public relations, digital communication, and teamwork skills.",
    ],
  },
];

export function Experience() {
  return (
    <Section
      id="experience"
      eyebrow="Experience"
      title="Where I've contributed."
      description="Hands-on roles in research operations, campus outreach, and student leadership."
    >
      <div className="grid md:grid-cols-2 gap-6">
        {experiences.map((e, i) => (
          <article
            key={e.role}
            className="rounded-2xl border border-border bg-card p-7 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-smooth reveal"
            style={{ transitionDelay: `${i * 100}ms` }}
          >
            <div className="flex items-start justify-between gap-4 mb-5">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground shadow-glow">
                <e.icon className="h-5 w-5" />
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium whitespace-nowrap">
                {e.period}
              </span>
            </div>
            <h3 className="font-display text-xl font-semibold">{e.role}</h3>
            <p className="text-sm text-muted-foreground mb-5">{e.org}</p>
            <ul className="space-y-2.5">
              {e.bullets.map((b) => (
                <li
                  key={b}
                  className="flex gap-3 text-sm text-muted-foreground leading-relaxed"
                >
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}